dependencies = ["torch", "torchvision", "timm"]
